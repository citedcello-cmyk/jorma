document.addEventListener("DOMContentLoaded", () => {
  const searchInput = document.getElementById("searchInput");
  const gameGrid = document.getElementById("gameGrid");
  const cards = Array.from(gameGrid.querySelectorAll(".game-card"));
  const resultCount = document.getElementById("resultCount");
  const noResults = document.getElementById("noResults");

  function updateCount(visible) {
    resultCount.textContent = `${visible} of ${cards.length} games`;
  }

  function filterGames() {
    const query = searchInput.value.trim().toLowerCase();
    let visibleCount = 0;

    cards.forEach((card) => {
      const title = card.dataset.title.toLowerCase();
      const matches = title.includes(query);
      card.hidden = !matches;
      if (matches) visibleCount++;
    });

    noResults.hidden = visibleCount !== 0;
    updateCount(visibleCount);
  }

  searchInput.addEventListener("input", filterGames);
  updateCount(cards.length);
});
